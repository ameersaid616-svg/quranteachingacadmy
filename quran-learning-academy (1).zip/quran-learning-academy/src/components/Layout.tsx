import { Link } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import { COURSES, SITE, waLink } from "@/lib/site";

export function WhatsAppIcon({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M17.47 14.38c-.3-.15-1.75-.86-2.02-.96-.27-.1-.47-.15-.67.15-.2.3-.77.96-.94 1.16-.17.2-.35.22-.64.07-.3-.15-1.26-.46-2.4-1.48-.89-.79-1.49-1.77-1.66-2.07-.17-.3-.02-.46.13-.6.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.08-.15-.67-1.61-.92-2.2-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.79.37-.27.3-1.04 1.02-1.04 2.48s1.07 2.88 1.21 3.08c.15.2 2.1 3.2 5.08 4.49.71.31 1.26.49 1.69.63.71.23 1.36.2 1.87.12.57-.09 1.75-.72 2-1.41.25-.69.25-1.29.17-1.41-.07-.12-.27-.2-.57-.35M12.05 21.5h-.01a9.43 9.43 0 0 1-4.8-1.32l-.35-.2-3.57.93.95-3.48-.22-.36a9.4 9.4 0 0 1-1.44-5.02c0-5.2 4.24-9.44 9.45-9.44 2.52 0 4.9.99 6.68 2.77a9.38 9.38 0 0 1 2.76 6.68c0 5.21-4.24 9.44-9.45 9.44m8.04-17.48A11.3 11.3 0 0 0 12.04.7C5.78.7.68 5.8.68 12.06c0 2 .52 3.96 1.52 5.68L.58 23.7l6.1-1.6a11.33 11.33 0 0 0 5.37 1.37h.01c6.26 0 11.36-5.1 11.36-11.36 0-3.04-1.18-5.89-3.33-8.04" />
    </svg>
  );
}

export const btnGold =
  "inline-flex items-center justify-center gap-2 rounded-full bg-gold-gradient px-6 py-3 text-sm font-bold text-primary-foreground shadow-gold transition hover:brightness-110 hover:-translate-y-0.5";
export const btnOutline =
  "inline-flex items-center justify-center gap-2 rounded-full border border-primary/60 px-6 py-3 text-sm font-semibold text-primary transition hover:bg-primary hover:text-primary-foreground";
export const btnWa =
  "inline-flex items-center justify-center gap-2 rounded-full bg-whatsapp px-6 py-3 text-sm font-bold text-primary-foreground transition hover:brightness-110 hover:-translate-y-0.5";

const NAV = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About" },
  { to: "/courses", label: "Courses" },
  { to: "/contact", label: "Contact" },
] as const;

function Logo() {
  return (
    <Link to="/" className="flex items-center gap-3" aria-label={`${SITE.name} home`}>
      <span className="grid h-10 w-10 place-items-center rounded-full border border-primary/60 font-arabic text-xl text-primary">ق</span>
      <span className="font-display text-lg font-semibold leading-tight text-[color:var(--heading)] sm:text-xl">
        The Quran <span className="text-primary">Learning Academy</span>
      </span>
    </Link>
  );
}

function Header() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/85 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
        <Logo />
        <nav aria-label="Main" className="hidden items-center gap-8 md:flex">
          {NAV.map((n) => (
            <Link key={n.to} to={n.to} className="text-sm font-medium text-muted-foreground transition hover:text-primary" activeProps={{ className: "text-primary" }} activeOptions={{ exact: true }}>
              {n.label}
            </Link>
          ))}
          <Link to="/contact" className={btnGold + " px-5 py-2.5"}>Start Free Trial</Link>
        </nav>
        <button className="rounded-md p-2 text-primary md:hidden" aria-label="Toggle menu" aria-expanded={open} onClick={() => setOpen(!open)}>
          <svg className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" aria-hidden="true">
            {open ? <path d="M6 6l12 12M6 18L18 6" /> : <path d="M4 7h16M4 12h16M4 17h16" />}
          </svg>
        </button>
      </div>
      {open && (
        <nav aria-label="Mobile" className="flex flex-col gap-1 border-t border-border px-4 py-4 md:hidden">
          {NAV.map((n) => (
            <Link key={n.to} to={n.to} onClick={() => setOpen(false)} className="rounded-md px-3 py-2 text-foreground hover:bg-muted" activeProps={{ className: "text-primary" }} activeOptions={{ exact: true }}>
              {n.label}
            </Link>
          ))}
          <Link to="/contact" onClick={() => setOpen(false)} className={btnGold + " mt-2"}>Start Free Trial</Link>
        </nav>
      )}
    </header>
  );
}

function Footer() {
  return (
    <footer className="relative mt-24 border-t border-border bg-card">
      <div className="islamic-pattern absolute inset-0 opacity-60" aria-hidden="true" />
      <div className="relative mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-4">
        <div className="md:col-span-1">
          <Logo />
          <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
            Live one-to-one online Quran classes for children and adults, from the comfort of home. Start with a 3 Days Free Trial.
          </p>
        </div>
        <div>
          <h3 className="text-lg text-primary">Quick Links</h3>
          <ul className="mt-4 space-y-2 text-sm">
            {NAV.map((n) => <li key={n.to}><Link to={n.to} className="text-muted-foreground hover:text-primary">{n.label}</Link></li>)}
            <li><Link to="/contact" className="text-muted-foreground hover:text-primary">Start Free Trial</Link></li>
          </ul>
        </div>
        <div>
          <h3 className="text-lg text-primary">Courses</h3>
          <ul className="mt-4 space-y-2 text-sm">
            {COURSES.map((c) => <li key={c.slug}><Link to="/courses" hash={c.slug} className="text-muted-foreground hover:text-primary">{c.name}</Link></li>)}
          </ul>
        </div>
        <div>
          <h3 className="text-lg text-primary">Contact</h3>
          <ul className="mt-4 space-y-3 text-sm">
            <li><a href={`mailto:${SITE.email}`} className="break-all text-muted-foreground hover:text-primary">{SITE.email}</a></li>
            <li><a href={`tel:${SITE.phoneIntl}`} className="text-muted-foreground hover:text-primary">Mobile: {SITE.phoneDisplay}</a></li>
            <li><a href={waLink()} target="_blank" rel="noopener noreferrer" className={btnWa + " px-4 py-2"}><WhatsAppIcon className="h-4 w-4" /> Chat on WhatsApp</a></li>
          </ul>
        </div>
      </div>
      <div className="relative border-t border-border py-5 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} {SITE.name}. All rights reserved.
      </div>
    </footer>
  );
}

function FloatingWhatsApp() {
  return (
    <a href={waLink()} target="_blank" rel="noopener noreferrer" aria-label="Chat with us on WhatsApp"
      className="fixed bottom-5 right-5 z-50 grid h-14 w-14 place-items-center rounded-full bg-whatsapp text-primary-foreground shadow-gold transition hover:scale-110">
      <WhatsAppIcon className="h-7 w-7" />
    </a>
  );
}

export function SiteLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded focus:bg-primary focus:px-3 focus:py-2 focus:text-primary-foreground">Skip to content</a>
      <Header />
      <main id="main" className="flex-1">{children}</main>
      <Footer />
      <FloatingWhatsApp />
    </div>
  );
}

export function PageHero({ eyebrow, title, text }: { eyebrow: string; title: ReactNode; text: string }) {
  return (
    <section className="relative overflow-hidden border-b border-border">
      <div className="islamic-pattern absolute inset-0" aria-hidden="true" />
      <div className="absolute inset-0 bg-gradient-to-b from-transparent to-background" aria-hidden="true" />
      <div className="relative mx-auto max-w-4xl px-4 py-20 text-center sm:py-28 fade-up">
        <p className="text-xs font-bold uppercase tracking-[0.3em] text-primary">{eyebrow}</p>
        <h1 className="mt-4 text-4xl sm:text-6xl">{title}</h1>
        <p className="mx-auto mt-5 max-w-2xl text-lg text-muted-foreground">{text}</p>
      </div>
    </section>
  );
}

export function SectionTitle({ eyebrow, title, text }: { eyebrow: string; title: ReactNode; text?: string }) {
  return (
    <div className="mx-auto max-w-2xl text-center">
      <p className="text-xs font-bold uppercase tracking-[0.3em] text-primary">{eyebrow}</p>
      <h2 className="mt-3 text-3xl sm:text-5xl">{title}</h2>
      <div className="mx-auto mt-4 h-px w-24 bg-gold-gradient" aria-hidden="true" />
      {text && <p className="mt-4 text-muted-foreground">{text}</p>}
    </div>
  );
}

export function TrialCTA() {
  return (
    <section className="mx-auto mt-24 max-w-6xl px-4 sm:px-6">
      <div className="relative overflow-hidden rounded-3xl border border-primary/40 bg-card px-6 py-14 text-center sm:px-12">
        <div className="islamic-pattern absolute inset-0" aria-hidden="true" />
        <div className="relative">
          <p className="font-arabic text-2xl text-primary">بِسْمِ ٱللَّٰهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ</p>
          <h2 className="mt-4 text-3xl sm:text-5xl">Begin Your Quran Learning Journey with a <span className="text-gold-gradient">3 Days Free Trial.</span></h2>
          <p className="mx-auto mt-4 max-w-xl text-muted-foreground">Live one-to-one classes on Zoom, WhatsApp, Skype, or Google Meet — at a time that suits you.</p>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <Link to="/contact" className={btnGold}>Start Your 3 Days Free Trial</Link>
            <a href={waLink()} target="_blank" rel="noopener noreferrer" className={btnWa}><WhatsAppIcon /> WhatsApp Us</a>
          </div>
        </div>
      </div>
    </section>
  );
}
