import { createFileRoute, Link } from "@tanstack/react-router";
import hero from "@/assets/hero-quran.jpg";
import { btnGold, btnOutline, btnWa, SectionTitle, TrialCTA, WhatsAppIcon } from "@/components/Layout";
import { COURSES, PLATFORMS, SITE, waLink } from "@/lib/site";
import { pageMeta } from "@/lib/meta";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: pageMeta(
      "The Quran Learning Academy — Online One-to-One Quran Classes",
      "Learn Quran online with personalized live one-to-one classes: Noorani Qaida, Nazra, Tajweed, Tafseer and more. Start your 3 Days Free Trial.",
    ),
  }),
  component: Home,
});

const WHY = [
  { t: "One-to-One Attention", d: "Every class is live and dedicated to a single student, so lessons follow your pace." },
  { t: "Learn From Home", d: "No travel needed — join from anywhere using Zoom, WhatsApp, Skype, or Google Meet." },
  { t: "Flexible Timings", d: "Choose a class time that fits around school, work, and family routines." },
  { t: "All Levels Welcome", d: "From first Arabic letters to Tajweed and Tafseer, beginners and advanced learners alike." },
  { t: "Children & Adults", d: "Patient, structured lessons suitable for young learners, adults, and families." },
  { t: "Try Before You Commit", d: "Begin with a 3 Days Free Trial to experience the classes yourself." },
];

const FAQ = [
  { q: "How does the 3 Days Free Trial work?", a: "Fill in the free trial form or message us on WhatsApp. We will arrange three live one-to-one trial classes at a time that suits you." },
  { q: "Which platforms are used for classes?", a: "Classes are held live on Zoom, WhatsApp, Skype, or Google Meet — whichever you prefer." },
  { q: "Are the classes one-to-one?", a: "Yes. Every class is a live, personal session between the teacher and one student." },
  { q: "Who can join?", a: "Children and adults of any level — complete beginners to students who want to improve Tajweed or study Tafseer." },
  { q: "What do I need to attend?", a: "A phone, tablet, or computer with a stable internet connection and the app for your chosen platform." },
  { q: "How do I choose a class time?", a: "Tell us your preferred time in the registration form or on WhatsApp, and we will do our best to match it." },
];

function Home() {
  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <img src={hero} alt="An open Quran resting on a carved wooden stand with a mosque silhouette behind" width={1600} height={1008} className="absolute inset-0 h-full w-full object-cover opacity-45" fetchPriority="high" />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/85 to-background/30" aria-hidden="true" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" aria-hidden="true" />
        <div className="relative mx-auto max-w-7xl px-4 pb-24 pt-20 sm:px-6 sm:pt-28 lg:pb-32">
          <div className="max-w-2xl fade-up">
            <p className="inline-flex items-center gap-2 rounded-full border border-primary/40 bg-background/60 px-4 py-1.5 text-xs font-bold uppercase tracking-[0.25em] text-primary">
              {SITE.name}
            </p>
            <h1 className="mt-6 text-5xl leading-[1.05] sm:text-7xl">
              Learn Quran Online with <span className="text-gold-gradient">Personalized One-to-One</span> Classes
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-muted-foreground">
              Live, personal Quran lessons from the comfort of your home. Learn to read, recite with Tajweed, and understand the Quran — at your own pace, with a teacher focused only on you.
            </p>
            <div className="mt-9 flex flex-wrap gap-4">
              <Link to="/contact" className={btnGold + " px-7 py-4 text-base"}>Start Your 3 Days Free Trial</Link>
              <a href={waLink()} target="_blank" rel="noopener noreferrer" className={btnWa + " px-7 py-4 text-base"}><WhatsAppIcon /> WhatsApp Us</a>
            </div>
            <p className="mt-6 text-sm text-muted-foreground">Live classes on {PLATFORMS.join(" · ")}</p>
          </div>
        </div>
      </section>

      {/* One-to-one */}
      <section className="mx-auto grid max-w-7xl items-center gap-12 px-4 py-20 sm:px-6 lg:grid-cols-2">
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.3em] text-primary">Live One-to-One</p>
          <h2 className="mt-3 text-3xl sm:text-5xl">A teacher focused entirely on <span className="text-gold-gradient">you</span></h2>
          <p className="mt-5 leading-relaxed text-muted-foreground">
            In a one-to-one class, every minute is yours. Your teacher listens to your recitation, corrects pronunciation immediately, and adjusts each lesson to your level and goals — whether you are just starting with Noorani Qaida or refining your Tajweed.
          </p>
          <ul className="mt-6 space-y-3">
            {["Personal feedback in every lesson", "Lessons planned around your progress", "Comfortable, private learning environment"].map((x) => (
              <li key={x} className="flex items-start gap-3"><span className="mt-1.5 h-2 w-2 rotate-45 bg-primary" aria-hidden="true" />{x}</li>
            ))}
          </ul>
        </div>
        <div className="card-premium relative overflow-hidden p-10 text-center">
          <div className="islamic-pattern absolute inset-0" aria-hidden="true" />
          <p className="relative font-arabic text-4xl leading-loose text-primary sm:text-5xl">ٱقْرَأْ بِٱسْمِ رَبِّكَ ٱلَّذِى خَلَقَ</p>
          <p className="relative mt-4 text-muted-foreground">"Read in the name of your Lord who created." — Surah Al-'Alaq 96:1</p>
        </div>
      </section>

      {/* Courses */}
      <section className="relative py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <SectionTitle eyebrow="Courses & Services" title="What You Can Learn" text="Six structured courses for every stage of your Quran journey." />
          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {COURSES.map((c, i) => (
              <article key={c.slug} className="card-premium p-7">
                <div className="flex items-center justify-between">
                  <span className="font-display text-4xl text-primary/40">0{i + 1}</span>
                  <span className="font-arabic text-xl text-primary">{c.ar}</span>
                </div>
                <h3 className="mt-4 text-2xl">{c.name}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{c.desc}</p>
                <Link to="/contact" search={{ course: c.name }} className="mt-5 inline-block text-sm font-bold text-primary hover:underline">Book Free Trial →</Link>
              </article>
            ))}
          </div>
          <div className="mt-10 text-center"><Link to="/courses" className={btnOutline}>View All Courses</Link></div>
        </div>
      </section>

      {/* Platforms */}
      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
        <SectionTitle eyebrow="Online Platforms" title="Join From Any Device" text="Pick the platform you are most comfortable with." />
        <div className="mt-12 grid grid-cols-2 gap-4 md:grid-cols-4">
          {PLATFORMS.map((p) => (
            <div key={p} className="card-premium flex flex-col items-center gap-3 p-8 text-center">
              <span className="grid h-14 w-14 place-items-center rounded-full border border-primary/50 font-display text-2xl text-primary">{p[0]}</span>
              <span className="font-semibold text-[color:var(--heading)]">{p}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Why */}
      <section className="relative overflow-hidden border-y border-border bg-card py-20">
        <div className="islamic-pattern absolute inset-0" aria-hidden="true" />
        <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
          <SectionTitle eyebrow="Why Choose Us" title={<>Why Families Choose <span className="text-gold-gradient">{SITE.name}</span></>} />
          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {WHY.map((w) => (
              <div key={w.t} className="rounded-2xl border border-border bg-background/70 p-7">
                <span className="block h-3 w-3 rotate-45 bg-primary" aria-hidden="true" />
                <h3 className="mt-4 text-2xl">{w.t}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{w.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="mx-auto max-w-3xl px-4 py-20 sm:px-6">
        <SectionTitle eyebrow="FAQ" title="Frequently Asked Questions" />
        <div className="mt-12 space-y-3">
          {FAQ.map((f) => (
            <details key={f.q} className="group rounded-xl border border-border bg-card p-5 open:border-primary/50">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-semibold text-[color:var(--heading)]">
                {f.q}<span className="text-xl text-primary transition group-open:rotate-45" aria-hidden="true">+</span>
              </summary>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{f.a}</p>
            </details>
          ))}
        </div>
      </section>

      <TrialCTA />
    </>
  );
}
