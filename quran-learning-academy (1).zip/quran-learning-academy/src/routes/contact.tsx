import { createFileRoute } from "@tanstack/react-router";
import { useRef, useState, type FormEvent } from "react";
import { z } from "zod";
import { btnGold, btnWa, PageHero, WhatsAppIcon } from "@/components/Layout";
import { COURSES, PLATFORMS, SITE, waLink } from "@/lib/site";
import { pageMeta } from "@/lib/meta";

export const Route = createFileRoute("/contact")({
  validateSearch: (s: Record<string, unknown>): { course?: string } =>
    typeof s["course"] === "string" ? { course: s["course"].slice(0, 50) } : {},
  head: () => ({
    meta: pageMeta(
      "Contact & Free Trial — The Quran Learning Academy",
      "Register for a 3 Days Free Trial of live one-to-one online Quran classes. Contact us by email or WhatsApp.",
    ),
  }),
  component: Contact,
});

// Email delivery via FormSubmit (no API key needed; the inbox owner confirms once by email).
const FORM_ENDPOINT = `https://formsubmit.co/ajax/${SITE.email}`;
const TIMES = ["Early Morning (6–9 AM)", "Morning (9 AM–12 PM)", "Afternoon (12–4 PM)", "Evening (4–8 PM)", "Night (8–11 PM)", "Weekend only"];

const schema = z.object({
  studentName: z.string().trim().min(2, "Please enter the student's name").max(100),
  parentName: z.string().trim().max(100).optional().or(z.literal("")),
  whatsapp: z.string().trim().regex(/^\+?[0-9\s-]{7,20}$/, "Enter a valid WhatsApp number (digits, may start with +)"),
  email: z.string().trim().email("Enter a valid email").max(255).optional().or(z.literal("")),
  age: z.string().trim().regex(/^\d{0,3}$/, "Age must be a number").optional().or(z.literal("")),
  course: z.string().min(1, "Please select a course"),
  platform: z.string().min(1, "Please select a platform"),
  time: z.string().min(1, "Please select a preferred time"),
  message: z.string().trim().max(1000, "Message must be under 1000 characters").optional().or(z.literal("")),
});
type Data = z.infer<typeof schema>;
type Errors = Partial<Record<keyof Data, string>>;

const field = "mt-1.5 w-full rounded-lg border border-input bg-background px-4 py-3 text-[color:var(--heading)] placeholder:text-muted-foreground/60 focus:border-primary focus:outline-none focus:ring-2 focus:ring-ring/40";

function buildWaMessage(d: Partial<Data>) {
  return [
    "Assalamu Alaikum! I would like to request the 3 Days Free Trial at The Quran Learning Academy.",
    "",
    `Student Name: ${d.studentName || "-"}`,
    d.parentName ? `Parent/Guardian: ${d.parentName}` : "",
    `WhatsApp: ${d.whatsapp || "-"}`,
    d.email ? `Email: ${d.email}` : "",
    d.age ? `Student Age: ${d.age}` : "",
    `Course: ${d.course || "-"}`,
    `Platform: ${d.platform || "-"}`,
    `Preferred Time: ${d.time || "-"}`,
    d.message ? `Message: ${d.message}` : "",
  ].filter((l) => l !== "").join("\n");
}

function Contact() {
  const { course } = Route.useSearch();
  const formRef = useRef<HTMLFormElement>(null);
  const [startedAt] = useState(() => Date.now());
  const [errors, setErrors] = useState<Errors>({});
  const [status, setStatus] = useState<"idle" | "sending" | "success" | "error">("idle");
  const [errMsg, setErrMsg] = useState("");

  const read = () => {
    const fd = new FormData(formRef.current!);
    return Object.fromEntries(fd.entries()) as Record<string, string>;
  };

  const validate = () => {
    const raw = read();
    const r = schema.safeParse(raw);
    if (!r.success) {
      const e: Errors = {};
      r.error.issues.forEach((i) => { const k = i.path[0] as keyof Data; if (!e[k]) e[k] = i.message; });
      setErrors(e);
      const first = formRef.current?.querySelector<HTMLElement>(`[name="${Object.keys(e)[0]}"]`);
      first?.focus();
      return null;
    }
    setErrors({});
    return { data: r.data, raw };
  };

  const onSubmit = async (ev: FormEvent) => {
    ev.preventDefault();
    const v = validate();
    if (!v) return;
    // Spam protection: honeypot + minimum fill time
    if (v.raw["_honey"] || Date.now() - startedAt < 3000) { setStatus("success"); return; }
    setStatus("sending");
    try {
      const d = v.data;
      const res = await fetch(FORM_ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({
          _subject: `New 3 Days Free Trial Request — ${d.studentName}`,
          _template: "table",
          _captcha: "false",
          _replyto: d.email || undefined,
          "Student Name": d.studentName,
          "Parent/Guardian Name": d.parentName || "-",
          "WhatsApp Number": d.whatsapp,
          "Email Address": d.email || "-",
          "Student Age": d.age || "-",
          Course: d.course,
          "Preferred Platform": d.platform,
          "Preferred Time": d.time,
          Message: d.message || "-",
        }),
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok || json.success === "false" || json.success === false) throw new Error(json.message || "Submission failed");
      setStatus("success");
      formRef.current?.reset();
    } catch (e) {
      setStatus("error");
      setErrMsg(e instanceof Error ? e.message : "Something went wrong.");
    }
  };

  const sendWhatsApp = () => {
    const v = validate();
    if (!v) return;
    window.open(waLink(buildWaMessage(v.data)), "_blank", "noopener,noreferrer");
  };

  const Err = ({ k }: { k: keyof Data }) => errors[k] ? <p id={`${k}-err`} className="mt-1 text-sm text-destructive">{errors[k]}</p> : null;
  const a = (k: keyof Data) => ({ name: k, id: k, "aria-invalid": !!errors[k], "aria-describedby": errors[k] ? `${k}-err` : undefined });

  return (
    <>
      <PageHero eyebrow="Contact & Free Trial" title={<>Request Your <span className="text-gold-gradient">3 Days Free Trial</span></>}
        text="Fill in the form below and we will contact you on WhatsApp to schedule your live one-to-one trial classes." />
      <section className="mx-auto grid max-w-7xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-[1fr_1.6fr]">
        <aside className="space-y-5">
          <div className="card-premium p-7">
            <h2 className="text-2xl">Contact Details</h2>
            <dl className="mt-5 space-y-4 text-sm">
              <div><dt className="text-xs font-bold uppercase tracking-widest text-primary">Email</dt><dd><a className="break-all text-[color:var(--heading)] hover:text-primary" href={`mailto:${SITE.email}`}>{SITE.email}</a></dd></div>
              <div><dt className="text-xs font-bold uppercase tracking-widest text-primary">WhatsApp / Mobile</dt><dd><a className="text-[color:var(--heading)] hover:text-primary" href={`tel:${SITE.phoneIntl}`}>{SITE.phoneDisplay} ({SITE.phoneIntl})</a></dd></div>
              <div><dt className="text-xs font-bold uppercase tracking-widest text-primary">Class Type</dt><dd className="text-[color:var(--heading)]">Live One-to-One Online Classes</dd></div>
              <div><dt className="text-xs font-bold uppercase tracking-widest text-primary">Platforms</dt><dd className="text-[color:var(--heading)]">{PLATFORMS.join(", ")}</dd></div>
            </dl>
            <a href={waLink()} target="_blank" rel="noopener noreferrer" className={btnWa + " mt-6 w-full"}><WhatsAppIcon /> Chat on WhatsApp</a>
          </div>
          <div className="rounded-2xl border border-border bg-card p-7">
            <h2 className="text-2xl">How It Works</h2>
            <ol className="mt-4 list-decimal space-y-2 pl-5 text-sm text-muted-foreground">
              <li>Complete the form with the student's details.</li>
              <li>Send by email, or via WhatsApp for a faster reply.</li>
              <li>We will contact you to confirm your trial schedule.</li>
              <li>Join your 3 free live classes on your chosen platform.</li>
            </ol>
          </div>
        </aside>

        <form ref={formRef} onSubmit={onSubmit} noValidate className="card-premium p-6 hover:translate-y-0 sm:p-10" aria-labelledby="form-title">
          <h2 id="form-title" className="text-3xl">Free Trial Registration</h2>
          <p className="mt-1 text-sm text-muted-foreground">Fields marked * are required.</p>
          {/* honeypot */}
          <div className="hidden" aria-hidden="true"><label>Leave empty<input name="_honey" tabIndex={-1} autoComplete="off" /></label></div>

          <div className="mt-8 grid gap-5 sm:grid-cols-2">
            <div><label htmlFor="studentName" className="text-sm font-semibold">Student Name *</label><input {...a("studentName")} className={field} autoComplete="name" maxLength={100} required /><Err k="studentName" /></div>
            <div><label htmlFor="parentName" className="text-sm font-semibold">Parent/Guardian Name <span className="text-muted-foreground">(optional)</span></label><input {...a("parentName")} className={field} maxLength={100} /><Err k="parentName" /></div>
            <div><label htmlFor="whatsapp" className="text-sm font-semibold">WhatsApp Number *</label><input {...a("whatsapp")} type="tel" placeholder="+44 7700 900000" className={field} autoComplete="tel" maxLength={20} required /><Err k="whatsapp" /></div>
            <div><label htmlFor="email" className="text-sm font-semibold">Email Address <span className="text-muted-foreground">(optional)</span></label><input {...a("email")} type="email" className={field} autoComplete="email" maxLength={255} /><Err k="email" /></div>
            <div><label htmlFor="age" className="text-sm font-semibold">Student Age <span className="text-muted-foreground">(optional)</span></label><input {...a("age")} inputMode="numeric" className={field} maxLength={3} /><Err k="age" /></div>
            <div><label htmlFor="course" className="text-sm font-semibold">Select Course *</label>
              <select {...a("course")} defaultValue={COURSES.some((c) => c.name === course) ? course : ""} className={field} required>
                <option value="" disabled>Choose a course</option>
                {COURSES.map((c) => <option key={c.slug}>{c.name}</option>)}
                <option>Not sure — please advise</option>
              </select><Err k="course" /></div>
            <div><label htmlFor="platform" className="text-sm font-semibold">Preferred Class Platform *</label>
              <select {...a("platform")} defaultValue="" className={field} required>
                <option value="" disabled>Choose a platform</option>
                {PLATFORMS.map((p) => <option key={p}>{p}</option>)}
              </select><Err k="platform" /></div>
            <div><label htmlFor="time" className="text-sm font-semibold">Preferred Class Time *</label>
              <select {...a("time")} defaultValue="" className={field} required>
                <option value="" disabled>Choose a time</option>
                {TIMES.map((t) => <option key={t}>{t}</option>)}
              </select><Err k="time" /></div>
            <div className="sm:col-span-2"><label htmlFor="message" className="text-sm font-semibold">Message or Additional Information</label>
              <textarea {...a("message")} rows={4} maxLength={1000} className={field} placeholder="Your time zone, current level, or any questions…" /><Err k="message" /></div>
          </div>

          <div role="status" aria-live="polite" className="mt-6">
            {status === "success" && <p className="rounded-lg border border-success/50 bg-success/10 p-4 text-sm text-success">JazakAllah Khair! Your free trial request has been sent. We will contact you on WhatsApp soon, in shaa Allah.</p>}
            {status === "error" && <p className="rounded-lg border border-destructive/50 bg-destructive/10 p-4 text-sm text-destructive">Sorry, your request could not be sent by email ({errMsg}). Please use the WhatsApp button below or email us at {SITE.email}.</p>}
          </div>

          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <button type="submit" disabled={status === "sending"} className={btnGold + " flex-1 py-4 text-base disabled:opacity-60"}>
              {status === "sending" ? "Sending…" : "Request Your 3 Days Free Trial"}
            </button>
            <button type="button" onClick={sendWhatsApp} className={btnWa + " flex-1 py-4 text-base"}><WhatsAppIcon /> Send via WhatsApp</button>
          </div>
        </form>
      </section>
    </>
  );
}
