# The Quran Learning Academy — Setup & Hosting

## Pages
- `/` Home · `/about` About Us · `/courses` Courses & Services · `/contact` Contact & Free Trial
- Shared layout (header, footer, floating WhatsApp): `src/components/Layout.tsx`
- Shared styles/theme: `src/styles.css` · Academy details: `src/lib/site.ts`

## Contact form (email delivery)
The form posts to **FormSubmit** (`https://formsubmit.co/ajax/ameersaid.online@gmail.com`). No API key is used, so nothing secret is in the browser code.

**One-time activation (required):**
1. Publish the site, open the Contact page and submit one test request.
2. FormSubmit sends an "Activate Form" email to ameersaid.online@gmail.com — click **Activate**.
3. From then on every request arrives in that inbox as a formatted table.
   Until activated, submissions are NOT delivered — visitors can still use "Send via WhatsApp".
4. Optional: after activation FormSubmit shows a random alias; replace the email in `FORM_ENDPOINT` (src/routes/contact.tsx) with that alias to hide the address from bots.

Spam protection: hidden honeypot field, minimum fill-time check, input validation (zod) with length limits.

**Alternative — Formspree:** create a form at formspree.io, then set `FORM_ENDPOINT` to `https://formspree.io/f/<your-id>` (the form ID is public, not a secret).

## WhatsApp
All WhatsApp buttons use `https://wa.me/92345198572` with a prefilled message. "Send via WhatsApp" on the form opens WhatsApp with all form details filled in.

## Preview locally
```
bun install     # or npm install
bun run dev     # open http://localhost:8080
```

## Publish online
- **Lovable:** click Publish (top-right) — done, with optional custom domain.
- **Elsewhere:** `bun run build` produces an edge-ready build (Cloudflare Workers compatible). Deploy with `npx wrangler deploy` to Cloudflare.
