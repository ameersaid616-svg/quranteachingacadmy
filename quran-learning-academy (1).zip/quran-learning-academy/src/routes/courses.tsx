import { createFileRoute, Link } from "@tanstack/react-router";
import { btnGold, btnWa, PageHero, SectionTitle, TrialCTA, WhatsAppIcon } from "@/components/Layout";
import { COURSES, PLATFORMS, waLink } from "@/lib/site";
import { pageMeta } from "@/lib/meta";

export const Route = createFileRoute("/courses")({
  head: () => ({
    meta: pageMeta(
      "Courses & Services — The Quran Learning Academy",
      "Noorani Qaida, Nazra Quran, Tajweed, Tafseer, Deeni Masail and Deeni Books — live one-to-one online classes. Book your free trial.",
    ),
  }),
  component: Courses,
});

const STEPS = [
  { t: "Register", d: "Fill in the free trial form or message us on WhatsApp." },
  { t: "Choose Platform", d: `Select ${PLATFORMS.join(", ")}.` },
  { t: "Pick a Time", d: "Tell us when you are available and we will schedule your class." },
  { t: "Join Live", d: "Open the link at class time and learn one-to-one with your teacher." },
];

function Courses() {
  return (
    <>
      <PageHero eyebrow="Courses & Services" title={<>Our <span className="text-gold-gradient">Quran Courses</span></>}
        text="Six live one-to-one courses — from your very first Arabic letter to understanding the meanings of the Quran." />
      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {COURSES.map((c, i) => (
            <article id={c.slug} key={c.slug} className="card-premium relative flex scroll-mt-24 flex-col overflow-hidden p-8">
              <div className="islamic-pattern absolute -right-10 -top-10 h-40 w-40 opacity-70" aria-hidden="true" />
              <div className="relative flex items-center justify-between">
                <span className="font-display text-5xl text-primary/40">0{i + 1}</span>
                <span className="font-arabic text-2xl text-primary">{c.ar}</span>
              </div>
              <h2 className="relative mt-4 text-3xl">{c.name}</h2>
              <p className="relative mt-3 flex-1 text-muted-foreground">{c.desc}</p>
              <div className="relative mt-6 flex flex-wrap gap-3">
                <Link to="/contact" search={{ course: c.name }} className={btnGold + " px-5 py-2.5"}>Book Free Trial</Link>
                <a href={waLink(`Assalamu Alaikum! I am interested in the ${c.name} course at The Quran Learning Academy. Please guide me about the 3 Days Free Trial.`)} target="_blank" rel="noopener noreferrer" className={btnWa + " px-5 py-2.5"} aria-label={`Ask about ${c.name} on WhatsApp`}>
                  <WhatsAppIcon className="h-4 w-4" /> WhatsApp
                </a>
              </div>
            </article>
          ))}
        </div>
      </section>
      <section className="relative overflow-hidden border-y border-border bg-card py-20">
        <div className="islamic-pattern absolute inset-0" aria-hidden="true" />
        <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
          <SectionTitle eyebrow="How Classes Work" title="Live One-to-One Classes Online"
            text="Attend from home on Zoom, WhatsApp, Skype, or Google Meet using a phone, tablet, or computer with a stable internet connection." />
          <ol className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {STEPS.map((s, i) => (
              <li key={s.t} className="rounded-2xl border border-border bg-background/70 p-7">
                <span className="grid h-10 w-10 place-items-center rounded-full bg-gold-gradient font-bold text-primary-foreground">{i + 1}</span>
                <h3 className="mt-4 text-2xl">{s.t}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{s.d}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>
      <TrialCTA />
    </>
  );
}
