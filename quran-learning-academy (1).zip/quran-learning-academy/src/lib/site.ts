export const SITE = {
  name: "The Quran Learning Academy",
  email: "ameersaid.online@gmail.com",
  phoneDisplay: "0345 1985 72",
  phoneIntl: "+92345198572",
  waNumber: "92345198572",
};

export const DEFAULT_WA_MSG =
  "Assalamu Alaikum! I am interested in online Quran classes at The Quran Learning Academy. Please guide me about the 3 Days Free Trial.";

export const waLink = (msg: string = DEFAULT_WA_MSG) =>
  `https://wa.me/${SITE.waNumber}?text=${encodeURIComponent(msg)}`;

export const COURSES = [
  { slug: "noorani-qaida", name: "Noorani Qaida", ar: "القاعدة النورانية", desc: "Learn Arabic letters, pronunciation, and Quran reading fundamentals." },
  { slug: "nazra-quran", name: "Nazra Quran", ar: "ناظرة القرآن", desc: "Improve Quran reading fluency and accuracy." },
  { slug: "tajweed", name: "Tajweed", ar: "التجويد", desc: "Learn Quran recitation rules and correct pronunciation." },
  { slug: "tafseer", name: "Tafseer", ar: "التفسير", desc: "Study Quranic meanings, explanations, and lessons." },
  { slug: "deeni-masail", name: "Deeni Masail", ar: "المسائل الدينية", desc: "Learn essential Islamic guidance and religious matters." },
  { slug: "deeni-books", name: "Deeni Books", ar: "الكتب الدينية", desc: "Study selected Islamic books through guided online lessons." },
] as const;

export const PLATFORMS = ["Zoom", "WhatsApp", "Skype", "Google Meet"] as const;
