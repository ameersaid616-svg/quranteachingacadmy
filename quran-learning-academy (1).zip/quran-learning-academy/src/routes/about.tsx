import { createFileRoute } from "@tanstack/react-router";
import { PageHero, SectionTitle, TrialCTA } from "@/components/Layout";
import { SITE } from "@/lib/site";
import { pageMeta } from "@/lib/meta";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: pageMeta(
      "About Us — The Quran Learning Academy",
      "Our mission: help students of every level learn the Quran correctly through personalized live one-to-one online classes from home.",
    ),
  }),
  component: About,
});

const BLOCKS = [
  { t: "Our Mission", d: "To make authentic Quran learning accessible to every home, helping each student read, recite, and understand the Quran with confidence and love." },
  { t: "Our Educational Goals", d: "Build strong reading foundations, develop correct Tajweed, nurture understanding of Quranic meanings, and share essential Islamic guidance for daily life." },
  { t: "Learning the Quran Correctly", d: "Correct pronunciation preserves the meaning of the words of Allah. Careful attention to each letter and rule of Tajweed is at the heart of how we teach." },
  { t: "Personalized One-to-One", d: "Each lesson is a live session with one student, so the teacher can listen closely, correct gently, and move at the right pace." },
  { t: "Flexible Classes From Home", d: "Learn on Zoom, WhatsApp, Skype, or Google Meet at a time that suits your family — no commuting required." },
  { t: "Support at Every Level", d: "Whether you are learning the Arabic letters for the first time or studying Tafseer, lessons are tailored to where you are." },
];

function About() {
  return (
    <>
      <PageHero eyebrow="About Us" title={<>About <span className="text-gold-gradient">{SITE.name}</span></>}
        text={`${SITE.name} is an online Quran teaching academy offering live one-to-one classes for children and adults, wherever they are in the world.`} />
      <section className="mx-auto max-w-3xl px-4 py-20 text-center sm:px-6">
        <p className="text-lg leading-relaxed text-muted-foreground">
          We believe learning the Quran should be personal, patient, and accessible. That is why every class at {SITE.name} is taught live and one-to-one — giving each student the focused guidance they need to read correctly, recite beautifully, and grow in understanding.
        </p>
      </section>
      <section className="mx-auto max-w-7xl px-4 sm:px-6">
        <SectionTitle eyebrow="What Guides Us" title="Our Approach to Quran Education" />
        <div className="mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {BLOCKS.map((b, i) => (
            <article key={b.t} className="card-premium p-8">
              <span className="font-display text-4xl text-primary/40">0{i + 1}</span>
              <h3 className="mt-3 text-2xl">{b.t}</h3>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{b.d}</p>
            </article>
          ))}
        </div>
      </section>
      <TrialCTA />
    </>
  );
}
